package info.bliki.wiki.template.expr.eval;


public interface IDouble1Function {
  public double evaluate(double arg1);
}
