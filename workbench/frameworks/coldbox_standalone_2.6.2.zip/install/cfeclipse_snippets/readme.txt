ColdBox Eclipse Snippets

Just place the ColdBox snippets folder under your snippets directory of your CFEclipse installation.

To find your snippets folder do the following:

Click on Window > Preferences > CFEclipse

On the right panel, you will see the snippets directory. There is where you place these files.

If you want, you can also run the ANT taks to copy and synchronize your snippets. Just make sure
you open the copy.properties file and update your eclipse installation directory.

Luis Majano
Jn 3:16