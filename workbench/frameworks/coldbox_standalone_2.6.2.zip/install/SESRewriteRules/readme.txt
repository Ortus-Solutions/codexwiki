This folder contains several rewrite engine rules for your convenience.

1) .htaccess 
	Is an apache mod_rewrite standard. Can also be used to be imported into other rewrite engines
2) IsapiRewrite4.ini 
	Helicon Isapi Rewrite
3) web.config
	IIS7 Microsoft Rewrite 